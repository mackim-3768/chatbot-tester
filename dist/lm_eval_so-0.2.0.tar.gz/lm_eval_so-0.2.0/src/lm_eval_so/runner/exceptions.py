from lm_eval_so.core.exceptions import BackendError

__all__ = ["BackendError"]
